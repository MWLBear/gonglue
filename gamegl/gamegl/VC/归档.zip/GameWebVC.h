//
//  GameWebVC.h
//  gamegl
//
//  Created by mac04 on 2019/5/27.
//  Copyright © 2019 game. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GameWebVC : UIViewController

@end

NS_ASSUME_NONNULL_END
